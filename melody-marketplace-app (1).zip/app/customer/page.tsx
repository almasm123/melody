import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Leaf } from "lucide-react"

export default async function CustomerPage() {
  const supabase = await createClient()
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <nav className="flex items-center justify-between px-6 py-4 border-b bg-white">
        <div className="flex items-center gap-2">
          <Leaf className="w-8 h-8 text-green-600" />
          <span className="text-2xl font-bold text-green-600">Melody</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-600">Welcome, {user.email}</span>
          <Button variant="outline" size="sm">
            Logout
          </Button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold mb-8">Customer Dashboard</h1>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-semibold mb-4">Browse Products</h2>
            <p className="text-gray-600 mb-4">Discover fresh products from local farmers</p>
            <Link href="/customer/products">
              <Button className="bg-green-600 hover:bg-green-700">Browse</Button>
            </Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <h2 className="text-xl font-semibold mb-4">My Orders</h2>
            <p className="text-gray-600 mb-4">Track and manage your orders</p>
            <Link href="/customer/orders">
              <Button className="bg-green-600 hover:bg-green-700">View Orders</Button>
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
