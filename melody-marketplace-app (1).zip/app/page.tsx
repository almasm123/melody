"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Leaf } from "lucide-react"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 border-b">
        <div className="flex items-center gap-2">
          <Leaf className="w-8 h-8 text-green-600" />
          <span className="text-2xl font-bold text-green-600">Melody</span>
        </div>
        <div className="flex gap-4">
          <Link href="/auth/login">
            <Button variant="outline">Login</Button>
          </Link>
          <Link href="/auth/sign-up">
            <Button className="bg-green-600 hover:bg-green-700">Sign Up</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 py-24 text-center">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">Fresh from Farm to Table</h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Connect directly with farmers, get verified fresh produce, and enjoy real-time delivery tracking.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="text-3xl mb-3">✓</div>
            <h3 className="font-semibold text-gray-900 mb-2">Video Verified</h3>
            <p className="text-gray-600">Every product verified through farm videos</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="text-3xl mb-3">📍</div>
            <h3 className="font-semibold text-gray-900 mb-2">Real-time Tracking</h3>
            <p className="text-gray-600">Track your delivery with live GPS updates</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="text-3xl mb-3">🌱</div>
            <h3 className="font-semibold text-gray-900 mb-2">Direct Connection</h3>
            <p className="text-gray-600">Support local farmers and fresh produce</p>
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <Link href="/auth/sign-up">
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              Get Started
            </Button>
          </Link>
          <Button size="lg" variant="outline">
            Learn More
          </Button>
        </div>
      </section>
    </main>
  )
}
