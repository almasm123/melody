import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="text-center max-w-sm">
        <h1 className="text-3xl font-bold mb-4">Check Your Email</h1>
        <p className="text-gray-600 mb-6">
          We&apos;ve sent you a verification link. Please check your email to confirm your account.
        </p>
        <Link href="/auth/login">
          <Button className="w-full">Back to Login</Button>
        </Link>
      </div>
    </div>
  )
}
