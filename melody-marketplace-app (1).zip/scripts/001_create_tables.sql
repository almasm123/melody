-- Create profiles table for user management
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer',
  full_name text,
  mobile text,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create farmer_profiles
create table if not exists public.farmer_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  village text,
  verification_status text default 'pending',
  verification_video_url text,
  farm_details jsonb,
  rating numeric default 0,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create driver_profiles
create table if not exists public.driver_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  vehicle_type text,
  vehicle_number text,
  license_number text,
  documents_url text,
  verification_status text default 'pending',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create customer_profiles
create table if not exists public.customer_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  preferences jsonb,
  addresses jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create products table
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  farmer_id uuid not null references auth.users(id) on delete cascade,
  product_type text not null,
  breed text,
  weight_range text,
  age_months integer,
  quantity integer,
  wholesale_price numeric not null,
  description text,
  verification_status text default 'pending',
  verified_badge boolean default false,
  rating numeric default 0,
  image_urls text[],
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create orders table
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  farmer_id uuid not null references auth.users(id) on delete cascade,
  driver_id uuid references auth.users(id) on delete set null,
  status text default 'pending',
  delivery_date timestamp with time zone,
  delivery_address text,
  total_amount numeric not null,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create order_items table
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  quantity integer not null,
  unit_price numeric not null,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create notifications table
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null,
  message text not null,
  read boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Create offers table
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  description text,
  discount_percentage numeric,
  max_uses integer,
  used_count integer default 0,
  active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- Enable RLS on all tables
alter table public.profiles enable row level security;
alter table public.farmer_profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.customer_profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.notifications enable row level security;
alter table public.offers enable row level security;

-- RLS Policies for profiles
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles_insert_own"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id);

create policy "profiles_delete_own"
  on public.profiles for delete
  using (auth.uid() = id);

-- RLS Policies for farmer_profiles
create policy "farmer_profiles_select_own"
  on public.farmer_profiles for select
  using (auth.uid() = id);

create policy "farmer_profiles_insert_own"
  on public.farmer_profiles for insert
  with check (auth.uid() = id);

create policy "farmer_profiles_update_own"
  on public.farmer_profiles for update
  using (auth.uid() = id);

-- RLS Policies for driver_profiles
create policy "driver_profiles_select_own"
  on public.driver_profiles for select
  using (auth.uid() = id);

create policy "driver_profiles_insert_own"
  on public.driver_profiles for insert
  with check (auth.uid() = id);

create policy "driver_profiles_update_own"
  on public.driver_profiles for update
  using (auth.uid() = id);

-- RLS Policies for customer_profiles
create policy "customer_profiles_select_own"
  on public.customer_profiles for select
  using (auth.uid() = id);

create policy "customer_profiles_insert_own"
  on public.customer_profiles for insert
  with check (auth.uid() = id);

create policy "customer_profiles_update_own"
  on public.customer_profiles for update
  using (auth.uid() = id);

-- RLS Policies for products - farmers can CRUD their own
create policy "products_select_public"
  on public.products for select
  using (true);

create policy "products_insert_own"
  on public.products for insert
  with check (auth.uid() = farmer_id);

create policy "products_update_own"
  on public.products for update
  using (auth.uid() = farmer_id);

create policy "products_delete_own"
  on public.products for delete
  using (auth.uid() = farmer_id);

-- RLS Policies for orders
create policy "orders_select_own"
  on public.orders for select
  using (auth.uid() = customer_id or auth.uid() = farmer_id or auth.uid() = driver_id);

create policy "orders_insert_own"
  on public.orders for insert
  with check (auth.uid() = customer_id);

create policy "orders_update_own"
  on public.orders for update
  using (auth.uid() = customer_id or auth.uid() = farmer_id or auth.uid() = driver_id);

-- RLS Policies for order_items
create policy "order_items_select"
  on public.order_items for select
  using (true);

-- RLS Policies for notifications
create policy "notifications_select_own"
  on public.notifications for select
  using (auth.uid() = user_id);

create policy "notifications_insert_own"
  on public.notifications for insert
  with check (auth.uid() = user_id);

-- RLS Policies for offers - public read
create policy "offers_select_public"
  on public.offers for select
  using (true);
